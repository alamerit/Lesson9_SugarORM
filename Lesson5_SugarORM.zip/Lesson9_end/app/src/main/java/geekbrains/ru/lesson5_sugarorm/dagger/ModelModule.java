package geekbrains.ru.lesson5_sugarorm.dagger;

import javax.inject.Singleton;

import dagger.Module;
import dagger.Provides;
import geekbrains.ru.lesson5_sugarorm.Model;
import geekbrains.ru.lesson5_sugarorm.OrmApp;
import geekbrains.ru.lesson5_sugarorm.Presenter;

@Singleton
@Module
class ModelModule {
    @Singleton
    @Provides
    Presenter getModel(){
        return new Model(OrmApp.getComponent());
    }
}
